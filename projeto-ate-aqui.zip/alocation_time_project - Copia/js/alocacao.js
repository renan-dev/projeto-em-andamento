var buscaHoras = document.getElementById("inse-hora");

buscaHoras.textContent;

console.log(buscaHoras.textContent);





    