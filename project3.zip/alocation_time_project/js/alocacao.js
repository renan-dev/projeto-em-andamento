var comboCidades = document.getElementById("cboCidades").onclick = function () {

        var opt0 = document.createElement("option");
        opt0.value = "0";
        opt0.value = "";
        comboCidades.add(opt0, comboCidades.options[0]);

        var opt1 = document.createElement("option");
        opt1.value = "ca";
        opt1.value = "CANOPUS";
        comboCidades.add(opt1, comboCidades.options[1]);

        var opt2 = document.createElement("option");
        opt2.value = "ct"; 
        opt2.value = "CTO";
        comboCidades.add(opt2, comboCidades.options[2]);

        var opt3 = document.createElement("option");
        opt3.value = "ho";
        opt3.value = "HOME OFFICE";
        comboCidades.add(opt3, comboCidades.options[3]);


}